<div id="alt-footer" class="fl-row fl-row-full-width">
	<div class="fl-row-content-wrap">
		<div class="fl-row-content fl-row-fixed-width fl-node-content">
			<div class="fl-col-group">
				<div class="fl-col" style="width: 100%;">
					<div class="fl-col-content fl-node-content">
						<div class="fl-module fl-module-rich-text">
							<div class="fl-module-content fl-node-content">
								<div class="fl-col-group">
									<div class="fl-col col-sm-6">New Human &copy; <?php echo date('Y'); ?> | All rights reserved</div>
									<div class="fl-col col-sm-6 text-right">
	
										<a href="<?php echo home_url('terms-and-conditions');?>">Terms and Conditions</a>
										<span>|</span>
										<a href="<?php echo home_url('privacy-policy');?>">Privacy Policy</a>

									</div>
								</div>
							</div>		
						</div>		
					</div>
				</div>
			</div>		
		</div>
	</div>
</div>