<style>
.global-alert{ display: none; }
</style>
<div class="fl-page">
	<div class="fl-builder container fl-content-full">
		<div class="row">
			<div id="header" class="fl-row-content-wrap">
			    <div class="global-alert">
		          Scheduled maintenance
		        </div><!-- end global-alert>
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
					<div class="col-sm-3"><a href="<?php echo home_url();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/logo-small.png"/></div>
					<div class="col-sm-9"></div>
				</div>
			</div>
		</div>
	</div>
</div>