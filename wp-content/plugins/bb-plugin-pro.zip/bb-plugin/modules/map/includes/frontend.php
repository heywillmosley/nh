<div class="fl-map">
	<iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD09zQ9PNDNNy9TadMuzRV_UsPUoWKntt8&q=<?php echo urlencode( $settings->address ); ?>" style="border:0;width:100%;height:<?php echo $settings->height; ?>px"></iframe>
</div>
