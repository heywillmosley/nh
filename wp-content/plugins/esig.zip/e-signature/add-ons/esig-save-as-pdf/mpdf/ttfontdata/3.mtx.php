<?php
$name='NothingYouCouldDo';
$type='TTF';
$desc=array (
  'CapHeight' => 740,
  'XHeight' => 451,
  'FontBBox' => '[-338 -397 1429 937]',
  'Flags' => 4,
  'Ascent' => 937,
  'Descent' => -397,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 400,
);
$unitsPerEm=1024;
$up=-75;
$ut=50;
$strp=250;
$strs=50;
$ttffile='/home/graceiss/public_html/dev.approveme.me/testserver/wp-content/plugins/e-signature/add-ons/esig-save-as-pdf/mpdf/ttfonts/NothingYouCouldDo.ttf';
$TTCfontID='0';
$originalsize=34920;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='3';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 939, -397, 0
// usWinAscent/usWinDescent = 937, -397
// hhea Ascent/Descent/LineGap = 937, -397, 0
$useOTL=0x0000;
$rtlPUAstr='';
?>