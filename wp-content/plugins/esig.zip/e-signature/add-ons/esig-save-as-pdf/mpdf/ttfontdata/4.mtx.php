<?php
$name='Zeyada';
$type='TTF';
$desc=array (
  'CapHeight' => 588,
  'XHeight' => 305,
  'FontBBox' => '[-274 -664 1213 912]',
  'Flags' => 4,
  'Ascent' => 912,
  'Descent' => -664,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 375,
);
$unitsPerEm=1024;
$up=-75;
$ut=50;
$strp=250;
$strs=50;
$ttffile='E:/xampp/htdocs/project/1.4.5/wp-content/plugins/e-signature/add-ons/esig-save-as-pdf/mpdf/ttfonts/Zeyada.ttf';
$TTCfontID='0';
$originalsize=63064;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='4';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 912, -664, 0
// usWinAscent/usWinDescent = 912, -664
// hhea Ascent/Descent/LineGap = 912, -664, 0
$useOTL=0x0000;
$rtlPUAstr='';
?>