<?php 

if ( ! defined( 'ABSPATH' ) ) { 
	exit; // Exit if accessed directly
}

?>
	<h1>	<?php _e('Welcome to esignature plugin', 'esig'); ?> </h1>
	
	<h2><?php _e('this is about e-signature plugin about us page', 'esig'); ?>  </h2>