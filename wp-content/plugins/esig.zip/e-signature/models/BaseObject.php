<?php
/**
 * Base Object Class
 *
 * A base class which proivdes a low level abstraction layer
 * @since 0.1.0
 * @author Micah Blu
 */
class WP_E_BaseObject{

}
