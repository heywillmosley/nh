<div id="esig-sad-admin-panel" style="display:none;">
	<div class="esig-sad-main-panels">
		
			<ul>
			<li>
				<input type="checkbox" /> 
				<input type="text" name="" placeholder="Label" value="" />
				<input type="hidden" class="hidden_checkbox" name="" value="">
			</li>
			
			<a href="" class="clone-btn" data-target=".checkbox-clone"><?php __('+ Add another','esig-sad');?></a>
			<div class="checkbox-clone" style="display:none;">
				<li>
					<input type="checkbox" />
					<input type="text" name="" placeholder="Label" value="" />
					<input type="hidden" class="hidden_checkbox" name="" value="">
				</li>
			</div>
			<p><a class="insert-btn primary button"><?php __('Insert','esig-sad');?></a></p>
			</ul>

	</div>
</div>